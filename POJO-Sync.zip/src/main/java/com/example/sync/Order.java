package com.example.sync;

import java.math.BigDecimal;

public class Order {
    private String orderId;
    private BigDecimal amount;

    public Order() { }

    public Order(String orderId, BigDecimal amount) {
        this.orderId = orderId;
        this.amount = amount;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Order{orderId='%s', amount=%s}".formatted(orderId, amount);
    }
}
