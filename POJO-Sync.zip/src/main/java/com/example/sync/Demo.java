package com.example.sync;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Demo {
    public static void main(String[] args) throws Exception {
        Path outDir = Path.of("data");

        List<User> users = List.of(
                new User("u01", "Alice"),
                new User("u02", "Bob")
        );
        List<Order> orders = List.of(
                new Order("o01", new BigDecimal("123.45"))
        );

        // Write
        AvroFileManager.write(users, outDir);
        AvroFileManager.write(orders, outDir);

        String today = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        // Read
        AvroFileManager.read(outDir.resolve("user_" + today + ".avro"))
                .forEach(u -> System.out.println("Read User: " + u));
        AvroFileManager.read(outDir.resolve("order_" + today + ".avro"))
                .forEach(o -> System.out.println("Read Order: " + o));
    }
}
