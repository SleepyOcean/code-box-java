package com.example.sync;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.avro.Schema;
import org.apache.avro.reflect.ReflectData;

public final class SchemaRegistry {
    private static final Map<String, Schema> byClass = new ConcurrentHashMap<>();
    private static final Map<String, Class<?>> byFullName = new ConcurrentHashMap<>();

    static {
        // register BigDecimal logical type conversion once
        ReflectData.AllowNull.get().addLogicalTypeConversion(new BigDecimalConversion());
    }

    private SchemaRegistry() { }

    public static Schema get(Class<?> clazz) {
        return byClass.computeIfAbsent(clazz.getName(), k -> {
            Schema schema = ReflectData.AllowNull.get().getSchema(clazz);
            byFullName.put(schema.getFullName(), clazz);
            return schema;
        });
    }

    public static Class<?> lookupByFullName(String fullName) {
        return byFullName.get(fullName);
    }
}
