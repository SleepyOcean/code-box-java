package com.example.sync;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;

public final class FileIntegrity {
    private FileIntegrity() { }

    private static byte[] md5(Path file) throws IOException {
        try (InputStream in = Files.newInputStream(file)) {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) {
                md.update(buf, 0, len);
            }
            return md.digest();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public static void writeMd5(Path file) throws IOException {
        byte[] digest = md5(file);
        Path md5File = Paths.get(file.toString() + ".md5");
        Files.writeString(md5File, Hex.encodeHexString(digest));
    }

    public static void verifyMd5(Path file) throws IOException {
        Path md5File = Paths.get(file.toString() + ".md5");
        if (Files.notExists(md5File)) {
            throw new IOException("MD5 file missing: " + md5File);
        }
        String recorded = Files.readString(md5File);
        String current = Hex.encodeHexString(md5(file));
        if (!recorded.equalsIgnoreCase(current)) {
            throw new IOException("MD5 mismatch for " + file);
        }
    }
}
