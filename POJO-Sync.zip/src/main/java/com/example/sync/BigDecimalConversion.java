package com.example.sync;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.ByteBuffer;

import org.apache.avro.Conversion;
import org.apache.avro.LogicalType;
import org.apache.avro.LogicalTypes;
import org.apache.avro.Schema;

public class BigDecimalConversion extends Conversion<BigDecimal> {

    @Override
    public Class<BigDecimal> getConvertedType() {
        return BigDecimal.class;
    }

    @Override
    public String getLogicalTypeName() {
        return "decimal";
    }

    @Override
    public BigDecimal fromBytes(ByteBuffer value, Schema schema, LogicalType type) {
        LogicalTypes.Decimal decimalType = (LogicalTypes.Decimal) type;
        return new BigDecimal(new BigInteger(value.array()), decimalType.getScale());
    }

    @Override
    public ByteBuffer toBytes(BigDecimal value, Schema schema, LogicalType type) {
        LogicalTypes.Decimal decimalType = (LogicalTypes.Decimal) type;
        BigInteger unscaled = value.setScale(decimalType.getScale()).unscaledValue();
        return ByteBuffer.wrap(unscaled.toByteArray());
    }
}
