package com.example.sync;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.file.CodecFactory;
import org.apache.avro.reflect.ReflectDatumReader;
import org.apache.avro.reflect.ReflectDatumWriter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public final class AvroFileManager {

    private AvroFileManager() { }

    public static <T> void write(List<T> records, Path dir) throws IOException {
        if (records == null || records.isEmpty()) {
            return;
        }
        Class<?> clazz = records.get(0).getClass();
        Schema schema = SchemaRegistry.get(clazz);

        if (Files.notExists(dir)) {
            Files.createDirectories(dir);
        }
        Path file = dir.resolve(buildFileName(clazz));

        try (DataFileWriter<T> writer = new DataFileWriter<>(new ReflectDatumWriter<>(schema))) {
            writer.setCodec(CodecFactory.zstandardCodec(3));
            writer.create(schema, file.toFile());
            for (T r : records) {
                writer.append(r);
            }
        }
        FileIntegrity.writeMd5(file);
    }

    public static List<Object> read(Path file) throws IOException {
        FileIntegrity.verifyMd5(file);

        List<Object> out = new ArrayList<>();

        try (DataFileReader<Object> reader =
                     new DataFileReader<>(file.toFile(), new ReflectDatumReader<>())) {

            reader.forEachRemaining(out::add);
        }
        return out;
    }

    private static String buildFileName(Class<?> clazz) {
        String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        return clazz.getSimpleName().toLowerCase() + "_" + date + ".avro";
    }
}
